import { useEffect, useMemo, useState } from "react";
import "./styles.css";

const STORAGE_KEY = "week-tracker-progress";
const 34_TASKS = TOTAL;

export default function App() {
  const [completed, setCompleted] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    } catch {
      return [];
    }
  });
  const [saved, setSaved] = useState(false);
  const completedSet = useMemo(() => new Set(completed), [completed]);
  const count = completed.length;
  const progress = TOTAL_TASKS ? (count / TOTAL_TASKS) * 100 : 0;

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(completed));
    setSaved(true);
    const timer = setTimeout(() => setSaved(false), 900);
    return () => clearTimeout(timer);
  }, [completed]);

  const toggleTask = (id) => {
    setCompleted((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  return (
    <div className="app">
      <div className="wrap">
        <header>
          <div className="kicker">Study tracker</div>
          <h1>9 weeks from resume gaps to a real, defensible skill set</h1>
          <p className="sub">TypeScript and testing come first because they're what actually ends an interview early. Design systems and AI come after the baseline is solid. Open "detailed topics" under any week to see exactly what's inside it before you commit to it.</p>
          <div className="progress-shell">
            <div className="progress-top">
              <span className="progress-label">Overall progress</span>
              <span className="progress-count">{count} / {TOTAL_TASKS} tasks</span>
            </div>
            <div className="progress-track"><div className="progress-fill" style={{ width: `${progress}%` }} /></div>
            <div className={`save-status ${saved ? "ok" : ""}`}>{saved ? "Saved." : "Progress saves automatically in this browser."}</div>
          </div>
          <div className="daily-note"><b>Running daily habit:</b> 30–45 min of DSA every day (NeetCode's Blind 75, in order) sits underneath all 9 weeks below — it's not called out per week so it doesn't get skipped when a week feels full.</div>
        </header>
        <div className="timeline">


    <div className="week" data-week="1">
      <div className="week-dot">1</div>
      <div className="week-card">
        <div className="week-head">
          <div>
            <h3 className="week-title">TypeScript foundations</h3>
            <span className="focus-tag tag-ts">TypeScript</span>
          </div>
          <span className="week-range">Week 1</span>
        </div>
        <ul className="task-list">
          <li className="task"><input data-task-id="w1t1" type="checkbox" checked={completedSet.has("w1t1")} onChange={() => toggleTask("w1t1")} type="checkbox"  /><label htmlFor="w1t1">Read "Basics" and "Everyday Types" in the TS Handbook</label></li>
          <li className="task"><input data-task-id="w1t2" type="checkbox" checked={completedSet.has("w1t2")} onChange={() => toggleTask("w1t2")} type="checkbox"  /><label htmlFor="w1t2">Convert one existing JS file (Ramp Ready or Duhlicious) to strict TypeScript</label></li>
          <li className="task"><input data-task-id="w1t3" type="checkbox" checked={completedSet.has("w1t3")} onChange={() => toggleTask("w1t3")} type="checkbox"  /><label htmlFor="w1t3">Watch freeCodeCamp's TypeScript course, first third</label></li>
          <li className="task"><input data-task-id="w1t4" type="checkbox" checked={completedSet.has("w1t4")} onChange={() => toggleTask("w1t4")} type="checkbox"  /><label htmlFor="w1t4">DSA: first 5 problems from NeetCode's arrays/hashing set</label></li>
        </ul>
        <div className="resources">
          <a href="https://www.typescriptlang.org/docs/handbook/intro.html" target="_blank" rel="noreferrer">TS Handbook</a>
          <a href="https://www.youtube.com/@freecodecamp" target="_blank" rel="noreferrer">freeCodeCamp (YouTube)</a>
          <a href="https://neetcode.io/roadmap" target="_blank" rel="noreferrer">NeetCode roadmap</a>
        </div>
        <details className="syllabus">
          <summary>Detailed topics in this week</summary>
          <div className="topic-group">
            <h4>Core TypeScript</h4>
            <ul>
              <li>Type inference vs. explicit annotation — when TS can figure it out on its own</li>
              <li>Primitive types: string, number, boolean, null, undefined, void, never</li>
              <li>Typing arrays and tuples</li>
              <li>Object types: inline object types vs. interfaces vs. type aliases, and when to use each</li>
              <li>Optional properties (?) and readonly properties</li>
              <li>Union types and literal types (e.g. "loading" | "success" | "error")</li>
              <li>Type narrowing: typeof checks, instanceof, the "in" operator, truthiness checks</li>
              <li>Function typing: parameter types, return types, optional and default parameters</li>
              <li>any vs. unknown vs. never — why "any" quietly defeats the point of TypeScript</li>
              <li>Type assertions ("as") — when it's legitimate and when it's a red flag in review</li>
            </ul>
          </div>
        </details>
      </div>
    </div>

    <div className="week" data-week="2">
      <div className="week-dot">2</div>
      <div className="week-card">
        <div className="week-head">
          <div>
            <h3 className="week-title">TypeScript inside React</h3>
            <span className="focus-tag tag-ts">TypeScript</span>
          </div>
          <span className="week-range">Week 2</span>
        </div>
        <ul className="task-list">
          <li className="task"><input data-task-id="w2t1" type="checkbox" checked={completedSet.has("w2t1")} onChange={() => toggleTask("w2t1")} type="checkbox"  /><label htmlFor="w2t1">Read the Components and Hooks sections of the React TypeScript Cheatsheet</label></li>
          <li className="task"><input data-task-id="w2t2" type="checkbox" checked={completedSet.has("w2t2")} onChange={() => toggleTask("w2t2")} type="checkbox"  /><label htmlFor="w2t2">Type props, state, and event handlers in one real component fully</label></li>
          <li className="task"><input data-task-id="w2t3" type="checkbox" checked={completedSet.has("w2t3")} onChange={() => toggleTask("w2t3")} type="checkbox"  /><label htmlFor="w2t3">Work through Total TypeScript's free generics tutorial</label></li>
          <li className="task"><input data-task-id="w2t4" type="checkbox" checked={completedSet.has("w2t4")} onChange={() => toggleTask("w2t4")} type="checkbox"  /><label htmlFor="w2t4">DSA: finish arrays/hashing, start two-pointer problems</label></li>
        </ul>
        <div className="resources">
          <a href="https://react-typescript-cheatsheet.netlify.app/" target="_blank" rel="noreferrer">React TS Cheatsheet</a>
          <a href="https://www.totaltypescript.com/tutorials" target="_blank" rel="noreferrer">Total TypeScript (free)</a>
          <a href="https://neetcode.io/roadmap" target="_blank" rel="noreferrer">NeetCode roadmap</a>
        </div>
        <details className="syllabus">
          <summary>Detailed topics in this week</summary>
          <div className="topic-group">
            <h4>Generics</h4>
            <ul>
              <li>Generic functions and generic interfaces</li>
              <li>Constraining generics with "extends"</li>
              <li>Why generics matter for reusable, typed components and hooks</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>Typing React specifically</h4>
            <ul>
              <li>Typing function components: the React.FC debate and why explicit prop typing is usually preferred</li>
              <li>Typing useState&lt;T&gt; and useReducer, including discriminated unions for reducer actions</li>
              <li>Typing event handlers: React.ChangeEvent&lt;HTMLInputElement&gt;, React.MouseEvent, React.FormEvent</li>
              <li>Typing children props and render-prop patterns</li>
              <li>Typing the Context API: typing a Context, its Provider, and useContext</li>
              <li>Typing custom hooks and their return values (including tuple returns)</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>Utility types</h4>
            <ul>
              <li>Partial, Required, Readonly</li>
              <li>Pick and Omit for shaping existing types</li>
              <li>Record for typing key-value structures</li>
              <li>Discriminated unions for modeling UI state (loading / success / error) cleanly</li>
            </ul>
          </div>
        </details>
      </div>
    </div>

    <div className="week" data-week="3">
      <div className="week-dot">3</div>
      <div className="week-card">
        <div className="week-head">
          <div>
            <h3 className="week-title">Testing fundamentals — Jest</h3>
            <span className="focus-tag tag-test">Testing</span>
          </div>
          <span className="week-range">Week 3</span>
        </div>
        <ul className="task-list">
          <li className="task"><input data-task-id="w3t1" type="checkbox" checked={completedSet.has("w3t1")} onChange={() => toggleTask("w3t1")} type="checkbox"  /><label htmlFor="w3t1">Work through Jest's official "Getting Started" guide</label></li>
          <li className="task"><input data-task-id="w3t2" type="checkbox" checked={completedSet.has("w3t2")} onChange={() => toggleTask("w3t2")} type="checkbox"  /><label htmlFor="w3t2">Write unit tests for 3 plain utility functions (no React yet)</label></li>
          <li className="task"><input data-task-id="w3t3" type="checkbox" checked={completedSet.has("w3t3")} onChange={() => toggleTask("w3t3")} type="checkbox"  /><label htmlFor="w3t3">Watch Codevolution's Jest & RTL playlist, Jest half</label></li>
          <li className="task"><input data-task-id="w3t4" type="checkbox" checked={completedSet.has("w3t4")} onChange={() => toggleTask("w3t4")} type="checkbox"  /><label htmlFor="w3t4">DSA: sliding-window problems</label></li>
        </ul>
        <div className="resources">
          <a href="https://jestjs.io/docs/getting-started" target="_blank" rel="noreferrer">Jest docs</a>
          <a href="https://www.youtube.com/@Codevolution" target="_blank" rel="noreferrer">Codevolution (YouTube)</a>
          <a href="https://neetcode.io/roadmap" target="_blank" rel="noreferrer">NeetCode roadmap</a>
        </div>
        <details className="syllabus">
          <summary>Detailed topics in this week</summary>
          <div className="topic-group">
            <h4>Jest mechanics</h4>
            <ul>
              <li>How a test runner and assertion library fit together</li>
              <li>describe / it / test blocks and how to structure a test file</li>
              <li>Common matchers: toBe, toEqual, toBeTruthy, toContain, toThrow</li>
              <li>Setup and teardown: beforeEach, afterEach, beforeAll, afterAll</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>Mocking</h4>
            <ul>
              <li>jest.fn(), mockReturnValue, mockImplementation</li>
              <li>jest.mock() for mocking entire modules</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>Practice and hygiene</h4>
            <ul>
              <li>Testing pure functions and utility logic first, before components</li>
              <li>Test file naming and organization conventions (*.test.ts, colocated vs. separate folders)</li>
              <li>What code coverage actually measures, and why 100% coverage isn't the real goal</li>
            </ul>
          </div>
        </details>
      </div>
    </div>

    <div className="week" data-week="4">
      <div className="week-dot">4</div>
      <div className="week-card">
        <div className="week-head">
          <div>
            <h3 className="week-title">Testing real components — RTL</h3>
            <span className="focus-tag tag-test">Testing</span>
          </div>
          <span className="week-range">Week 4</span>
        </div>
        <ul className="task-list">
          <li className="task"><input data-task-id="w4t1" type="checkbox" checked={completedSet.has("w4t1")} onChange={() => toggleTask("w4t1")} type="checkbox"  /><label htmlFor="w4t1">Read the React Testing Library intro docs</label></li>
          <li className="task"><input data-task-id="w4t2" type="checkbox" checked={completedSet.has("w4t2")} onChange={() => toggleTask("w4t2")} type="checkbox"  /><label htmlFor="w4t2">Write real tests for 4–5 components: render, queries, user-event</label></li>
          <li className="task"><input data-task-id="w4t3" type="checkbox" checked={completedSet.has("w4t3")} onChange={() => toggleTask("w4t3")} type="checkbox"  /><label htmlFor="w4t3">Add one async test: mock an API call, assert loading and error states</label></li>
          <li className="task"><input data-task-id="w4t4" type="checkbox" checked={completedSet.has("w4t4")} onChange={() => toggleTask("w4t4")} type="checkbox"  /><label htmlFor="w4t4">DSA: recursion basics + intro to trees</label></li>
        </ul>
        <div className="resources">
          <a href="https://testing-library.com/docs/react-testing-library/intro/" target="_blank" rel="noreferrer">RTL docs</a>
          <a href="https://www.youtube.com/@freecodecamp" target="_blank" rel="noreferrer">freeCodeCamp (YouTube)</a>
          <a href="https://neetcode.io/roadmap" target="_blank" rel="noreferrer">NeetCode roadmap</a>
        </div>
        <details className="syllabus">
          <summary>Detailed topics in this week</summary>
          <div className="topic-group">
            <h4>RTL philosophy and queries</h4>
            <ul>
              <li>Testing behavior, not implementation details — the core RTL principle</li>
              <li>getBy vs. queryBy vs. findBy, and when each is correct</li>
              <li>Accessible queries first: getByRole and getByLabelText, and why they're preferred over getByTestId</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>Interaction and async</h4>
            <ul>
              <li>fireEvent vs. userEvent, and why userEvent better simulates real usage</li>
              <li>Testing forms: text inputs, selects, checkboxes</li>
              <li>Testing async UI with waitFor and findBy queries</li>
              <li>Mocking API calls (mocking fetch/axios directly, or the concept behind tools like MSW)</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>Extra ground</h4>
            <ul>
              <li>Snapshot testing: what it catches well and where it becomes noise</li>
              <li>Testing custom hooks with renderHook</li>
            </ul>
          </div>
        </details>
      </div>
    </div>

    <div className="week" data-week="5">
      <div className="week-dot">5</div>
      <div className="week-card">
        <div className="week-head">
          <div>
            <h3 className="week-title">Design systems — vocabulary and tokens</h3>
            <span className="focus-tag tag-ds">Design systems</span>
          </div>
          <span className="week-range">Week 5</span>
        </div>
        <ul className="task-list">
          <li className="task"><input data-task-id="w5t1" type="checkbox" checked={completedSet.has("w5t1")} onChange={() => toggleTask("w5t1")} type="checkbox"  /><label htmlFor="w5t1">Work through Storybook's "Design Systems for Developers" tutorial</label></li>
          <li className="task"><input data-task-id="w5t2" type="checkbox" checked={completedSet.has("w5t2")} onChange={() => toggleTask("w5t2")} type="checkbox"  /><label htmlFor="w5t2">Define a token set (color, spacing, type scale) for one project</label></li>
          <li className="task"><input data-task-id="w5t3" type="checkbox" checked={completedSet.has("w5t3")} onChange={() => toggleTask("w5t3")} type="checkbox"  /><label htmlFor="w5t3">Read through shadcn/ui source to see real variant patterns</label></li>
          <li className="task"><input data-task-id="w5t4" type="checkbox" checked={completedSet.has("w5t4")} onChange={() => toggleTask("w5t4")} type="checkbox"  /><label htmlFor="w5t4">DSA: continue trees</label></li>
        </ul>
        <div className="resources">
          <a href="https://storybook.js.org/tutorials/design-systems-for-developers/" target="_blank" rel="noreferrer">Storybook: Design Systems</a>
          <a href="https://ui.shadcn.com/" target="_blank" rel="noreferrer">shadcn/ui</a>
          <a href="https://neetcode.io/roadmap" target="_blank" rel="noreferrer">NeetCode roadmap</a>
        </div>
        <details className="syllabus">
          <summary>Detailed topics in this week</summary>
          <div className="topic-group">
            <h4>Tokens</h4>
            <ul>
              <li>What a design token is: primitive tokens vs. semantic tokens (e.g. "blue-500" vs. "color-danger")</li>
              <li>Color tokens, spacing tokens, typography tokens</li>
              <li>Type scale: modular scale ratios and heading/body hierarchy</li>
              <li>Spacing scale: 4px/8px grid systems and why consistent spacing matters at scale</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>Component API design</h4>
            <ul>
              <li>Props vs. composition — when to add a prop vs. when to let consumers compose</li>
              <li>Controlled vs. uncontrolled components</li>
              <li>Variant patterns: how libraries express size/variant/state (the class-variance-authority pattern)</li>
              <li>Naming conventions for components and props that stay consistent across a system</li>
              <li>Theming approaches: CSS variables vs. theme objects</li>
            </ul>
          </div>
        </details>
      </div>
    </div>

    <div className="week" data-week="6">
      <div className="week-dot">6</div>
      <div className="week-card">
        <div className="week-head">
          <div>
            <h3 className="week-title">Build a real component library</h3>
            <span className="focus-tag tag-ds">Design systems</span>
          </div>
          <span className="week-range">Week 6</span>
        </div>
        <ul className="task-list">
          <li className="task"><input data-task-id="w6t1" type="checkbox" checked={completedSet.has("w6t1")} onChange={() => toggleTask("w6t1")} type="checkbox"  /><label htmlFor="w6t1">Install Storybook on one project</label></li>
          <li className="task"><input data-task-id="w6t2" type="checkbox" checked={completedSet.has("w6t2")} onChange={() => toggleTask("w6t2")} type="checkbox"  /><label htmlFor="w6t2">Document 5–6 components with real states and variants</label></li>
          <li className="task"><input data-task-id="w6t3" type="checkbox" checked={completedSet.has("w6t3")} onChange={() => toggleTask("w6t3")} type="checkbox"  /><label htmlFor="w6t3">Run an accessibility check with the Storybook a11y addon or axe DevTools, fix what it flags</label></li>
          <li className="task"><input data-task-id="w6t4" type="checkbox" checked={completedSet.has("w6t4")} onChange={() => toggleTask("w6t4")} type="checkbox"  /><label htmlFor="w6t4">DSA: light practice, revisit anything shaky from weeks 1–5</label></li>
        </ul>
        <div className="resources">
          <a href="https://storybook.js.org/docs" target="_blank" rel="noreferrer">Storybook docs</a>
          <a href="https://www.deque.com/axe/devtools/" target="_blank" rel="noreferrer">axe DevTools</a>
          <a href="https://neetcode.io/roadmap" target="_blank" rel="noreferrer">NeetCode roadmap</a>
        </div>
        <details className="syllabus">
          <summary>Detailed topics in this week</summary>
          <div className="topic-group">
            <h4>Storybook mechanics</h4>
            <ul>
              <li>Component Story Format (CSF): writing stories, args, and controls</li>
              <li>Documenting every meaningful state: default, hover/focus, disabled, loading, error</li>
              <li>Useful addons: the a11y addon and the viewport addon</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>Accessibility, hands-on</h4>
            <ul>
              <li>Core ARIA roles and when native HTML elements make them unnecessary</li>
              <li>Keyboard navigation: tab order, visible focus states, focus trapping in modals</li>
              <li>Color contrast basics and how to check it</li>
              <li>Testing with axe DevTools and by navigating your own UI with only a keyboard</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>Publishing the library</h4>
            <ul>
              <li>Repo structure and exports that make components easy to reuse</li>
              <li>Writing a README that explains the "why," not just the "what"</li>
            </ul>
          </div>
        </details>
      </div>
    </div>

    <div className="week" data-week="7">
      <div className="week-dot">7</div>
      <div className="week-card">
        <div className="week-head">
          <div>
            <h3 className="week-title">Ship the library, start LLM basics</h3>
            <span className="focus-tag tag-ai">AI fundamentals</span>
          </div>
          <span className="week-range">Week 7</span>
        </div>
        <ul className="task-list">
          <li className="task"><input data-task-id="w7t1" type="checkbox" checked={completedSet.has("w7t1")} onChange={() => toggleTask("w7t1")} type="checkbox"  /><label htmlFor="w7t1">Polish the component library and push it to GitHub with a real README</label></li>
          <li className="task"><input data-task-id="w7t2" type="checkbox" checked={completedSet.has("w7t2")} onChange={() => toggleTask("w7t2")} type="checkbox"  /><label htmlFor="w7t2">Start Anthropic Academy's Claude fundamentals course</label></li>
          <li className="task"><input data-task-id="w7t3" type="checkbox" checked={completedSet.has("w7t3")} onChange={() => toggleTask("w7t3")} type="checkbox"  /><label htmlFor="w7t3">Work through chapters 1–4 of Anthropic's interactive prompt engineering tutorial</label></li>
        </ul>
        <div className="resources">
          <a href="https://anthropic.skilljar.com/" target="_blank" rel="noreferrer">Anthropic Academy</a>
          <a href="https://github.com/anthropics/prompt-eng-interactive-tutorial" target="_blank" rel="noreferrer">Prompt eng. tutorial</a>
        </div>
        <details className="syllabus">
          <summary>Detailed topics in this week</summary>
          <div className="topic-group">
            <h4>LLM basics</h4>
            <ul>
              <li>What a token is, and why context windows have a hard limit</li>
              <li>Temperature and sampling — why the same prompt can produce different outputs</li>
              <li>System prompts vs. user messages vs. assistant messages, and what each is for</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>Prompt engineering technique</h4>
            <ul>
              <li>Writing clear, unambiguous instructions</li>
              <li>Few-shot examples: showing the model what you want instead of just describing it</li>
              <li>Role prompting and why it changes output tone/behavior</li>
              <li>XML-tag structuring, which Claude specifically responds well to</li>
              <li>Chain-of-thought / step-by-step reasoning prompts</li>
              <li>Asking for structured output (e.g. JSON) and parsing it reliably</li>
            </ul>
          </div>
        </details>
      </div>
    </div>

    <div className="week" data-week="8">
      <div className="week-dot">8</div>
      <div className="week-card">
        <div className="week-head">
          <div>
            <h3 className="week-title">Build with the Claude API</h3>
            <span className="focus-tag tag-ai">AI fundamentals</span>
          </div>
          <span className="week-range">Week 8</span>
        </div>
        <ul className="task-list">
          <li className="task"><input data-task-id="w8t1" type="checkbox" checked={completedSet.has("w8t1")} onChange={() => toggleTask("w8t1")} type="checkbox"  /><label htmlFor="w8t1">Complete Anthropic's API fundamentals course (auth, requests, streaming)</label></li>
          <li className="task"><input data-task-id="w8t2" type="checkbox" checked={completedSet.has("w8t2")} onChange={() => toggleTask("w8t2")} type="checkbox"  /><label htmlFor="w8t2">Build one small real feature in Next.js calling the Claude API (e.g. a document summarizer)</label></li>
          <li className="task"><input data-task-id="w8t3" type="checkbox" checked={completedSet.has("w8t3")} onChange={() => toggleTask("w8t3")} type="checkbox"  /><label htmlFor="w8t3">Implement a genuinely streaming response in the UI, not just a spinner</label></li>
        </ul>
        <div className="resources">
          <a href="https://github.com/anthropics/courses" target="_blank" rel="noreferrer">Anthropic API course</a>
          <a href="https://docs.claude.com/" target="_blank" rel="noreferrer">Claude API docs</a>
        </div>
        <details className="syllabus">
          <summary>Detailed topics in this week</summary>
          <div className="topic-group">
            <h4>API mechanics</h4>
            <ul>
              <li>Authentication and API key handling</li>
              <li>Request/response shape: the messages array, roles, and model parameters</li>
              <li>Streaming responses: how server-sent events work and how to consume them client-side</li>
              <li>Basic error handling and rate limits</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>Beyond plain chat</h4>
            <ul>
              <li>Tool use / function calling: how the model decides to call a tool and how you define a tool schema</li>
              <li>RAG at a conceptual level: what embeddings are, what vector search does, and why retrieval happens before generation</li>
            </ul>
          </div>
          <div className="topic-group">
            <h4>The build itself</h4>
            <ul>
              <li>Wiring one real feature end to end: input → API call → streamed output → rendered UI</li>
              <li>Keeping the scope small and honest — a working summarizer beats an ambitious clone you can't fully explain</li>
            </ul>
          </div>
        </details>
      </div>
    </div>

    <div className="week" data-week="9">
      <div className="week-dot">9</div>
      <div className="week-card">
        <div className="week-head">
          <div>
            <h3 className="week-title">Consolidate and pressure-test</h3>
            <span className="focus-tag tag-review">Review</span>
          </div>
          <span className="week-range">Week 9</span>
        </div>
        <ul className="task-list">
          <li className="task"><input data-task-id="w9t1" type="checkbox" checked={completedSet.has("w9t1")} onChange={() => toggleTask("w9t1")} type="checkbox"  /><label htmlFor="w9t1">Finish and polish the Claude API project, write short notes on the tradeoffs you made</label></li>
          <li className="task"><input data-task-id="w9t2" type="checkbox" checked={completedSet.has("w9t2")} onChange={() => toggleTask("w9t2")} type="checkbox"  /><label htmlFor="w9t2">Run one timed mock DSA round: 3–4 medium problems, no notes</label></li>
          <li className="task"><input data-task-id="w9t3" type="checkbox" checked={completedSet.has("w9t3")} onChange={() => toggleTask("w9t3")} type="checkbox"  /><label htmlFor="w9t3">Re-read your own TypeScript and test code from weeks 1–4, fix anything you'd be embarrassed to explain</label></li>
          <li className="task"><input data-task-id="w9t4" type="checkbox" checked={completedSet.has("w9t4")} onChange={() => toggleTask("w9t4")} type="checkbox"  /><label htmlFor="w9t4">Write down one true, specific bullet point per phase — this becomes the honest resume rewrite</label></li>
        </ul>
        <div className="resources">
          <a href="https://neetcode.io/roadmap" target="_blank" rel="noreferrer">NeetCode roadmap</a>
        </div>
      </div>
    
        </div>
        <footer>Everything linked here is free. Resume rewrite comes after week 9, once every line on it is something you could defend in a follow-up question.</footer>
      </div>
    </div>
  );
}
